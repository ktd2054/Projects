/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.util.ArrayList;

/**
 *
 * @author Kshit Student ID: 12215318
 *
 * The MAPAnalyser class represents an analyzer for Mean Arterial Pressure (MAP)
 * data. It allows you to perform various operations on patient records,
 * including finding records by ID, calculating statistics, and more. This class
 * initializes data from tables, sorts patient records, and provides methods for
 * analysis.
 *
 */
public class MAPAnalyser {

    private int numRecords;
    private PatientRecord[] patients;

    public MAPAnalyser() {

        loadFromTables(); // call table to populate data
        sortByMAP(); // call this method to sort the data
    }

    /**
     * Retrieves an array containing all patient records.
     *
     * @return An array of PatientRecord objects representing all patient
     * records.
     */
    public PatientRecord[] getAllRecords() {
        return patients;
    }

    /**
     * Searches for and retrieves a patient record with the specified ID.
     *
     * @param id The ID of the patient record to find.
     * @return The PatientRecord object with the matching ID, or null if not
     * found.
     */
    public PatientRecord find(String id) {
        for (PatientRecord patient : patients) {
            if (patient.getId().equals(id)) { // check for match
                // Found the patient record with the given ID
                return patient;
            }
        }
        return null;
    }

    /**
     * Calculates and returns the lowest Mean Arterial Pressure (MAP) value
     * among all patient records.
     *
     * @return The lowest MAP value, or 0 if no records are available.
     */
    public double lowestMAP() {
        if (patients.length == 0) { // check whether there is a record or not.
            return 0; // if record not found return 0 as default
        }
        double lowest = patients[0].getMap();

        for (PatientRecord patient : patients) {
            double map = patient.getMap();
            if (map < lowest) {
                lowest = map;
            }
        }
        return lowest;

    }

    /**
     * Calculates and returns the highest Mean Arterial Pressure (MAP) value
     * among all patient records.
     *
     * @return The highest MAP value, or 0 if no records are available.
     */
    public double highestMAP() {
        if (patients.length == 0) {
            return 0; // check records, if not found any return 0 as a default value
        }

        double highest = patients[0].getMap(); // Initialize with the MAP of the first patient

        for (PatientRecord patient : patients) {
            double map = patient.getMap();
            if (map > highest) {
                highest = map;
            }
        }
        return highest;
    }

    /**
     * Calculates and returns the median Mean Arterial Pressure (MAP) value
     * among all patient records.
     *
     * @return The median MAP value, or 0 if no records are available.
     */
    public double medianMAP() {
        if (patients.length == 0) {
            return 0;
        }

        // Sort the patients array by MAP values 
        sortByMAP();

        // Calculate the median based on the sorted array
        int middle = patients.length / 2;
        if (patients.length % 2 == 0) {
            // If even number of records, take the average of two middle values
            double map1 = patients[middle - 1].getMap();
            double map2 = patients[middle].getMap();
            return (map1 + map2) / 2.0;
        } else {
            // If odd number of records, return the middle value
            return patients[middle].getMap();
        }
    }

    /**
     * Calculates and returns the average Mean Arterial Pressure (MAP) value
     * among all patient records.
     *
     * @return The average MAP value, or 0 if no records are available.
     */
    public double averageMAP() {
        if (patients.length == 0) {
            return 0;
        }

        double sum = 0;
        for (PatientRecord patient : patients) {
            sum += patient.getMap();
        }
        return sum / patients.length;
    }

    /**
     * Finds and returns a list of patient records with MAP values within a
     * specified range.
     *
     * @param map1 The lower bound of the MAP range.
     * @param map2 The upper bound of the MAP range.
     * @return An ArrayList containing patient records within the specified MAP
     * range.
     */
    public ArrayList<PatientRecord> find(double map1, double map2) {
        // no records found
        ArrayList<PatientRecord> list = new ArrayList<>();
        for (PatientRecord patient : patients) {
            double map = patient.getMap();
            if (map >= map1 && map <= map2) {
                list.add(patient);
            }
        }
        return list;
    }

    private void loadFromTables() {
        // 
        String[] ids = {
            "S10", "S45", "S30", "S15", "S40", "S25", "S35", "S20", "S50"
        };

        int[] sbps = {
            90, 70, 160, 110, 136, 180, 100, 60, 80
        };

        int[] dbps = {
            70, 45, 100, 60, 90, 100, 70, 45, 40
        };

        numRecords = ids.length;
        patients = new PatientRecord[numRecords];
        for (int i = 0; i < numRecords; i++) {
            double map = (1.0 / 3.0 * sbps[i]) + (2.0 / 3.0 * dbps[i]);
            String category = classify(map);
            PatientRecord record = new PatientRecord(ids[i], sbps[i], dbps[i], map, category);
            patients[i] = record;
        }
    }

    /**
     * Sorts the patient records array in ascending order based on their Mean
     * Arterial Pressure (MAP) values. Uses the selection sort algorithm.
     */
    private void sortByMAP() {

        // using selection sort for sorting patients array by MAP values
        int n = patients.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (patients[j].getMap() < patients[minIndex].getMap()) {
                    minIndex = j;
                }
            }
            // Swap patients[i] and patients[minIndex]
            PatientRecord temp = patients[i];
            patients[i] = patients[minIndex];
            patients[minIndex] = temp;
        }
    }

    /**
     * Classifies a patient's MAP value into a blood pressure category.
     *
     * @param map The Mean Arterial Pressure (MAP) value to classify.
     * @return A string representing the blood pressure category (e.g., "Low,"
     * "Normal,or "High").
     */
    private String classify(double map) {

        if (map < 70) {
            return "Low";
        } else if (map >= 70 && map < 90) {
            return "Normal";
        } else if (map >= 90) {
            return "High";
        } else {
            return "Unknown";
        }
    }
}
