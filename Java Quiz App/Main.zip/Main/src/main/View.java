/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.util.Scanner;

import java.util.ArrayList;

/**
 *
 * @author Kshit
 * Student ID: 12215318
 * The View class is responsible for user interactions and displaying the program's menu options.
 * It allows the user to input commands and interacts with the MAPAnalyser to perform operations on patient records.
 */
public class View {

    private MAPAnalyser analyser;
    private Scanner scanner;

    public View(MAPAnalyser analyser) {
        this.analyser = analyser;
        this.scanner = new Scanner(System.in);
    }

    public void commandLoop() {
        // Display the menu options
        System.out.println("The following commands are recognised ");
        System.out.println(" Display this menu                                              > 0");
        System.out.println(" Display the record for a specified patient                     > 1 PatientID");
        System.out.println(" Display records for all patients with MAP  within a range      > 2 MAP1 MAP2");
        System.out.println(" Display statistics (minimum, maximum, median, and average MAP) > 3");
        System.out.println(" Display all records                                            > 4");
        System.out.println(" Exit the application                                           > 9");

        int choice = -1;

        while (choice != 9) {

            System.out.print("> ");
            choice = scanner.nextInt();

            switch (choice) {
                case 0 -> {// Display the menu options

                    commandLoop();
                }
                case 1 -> {
                    //search and display a patient record

                    String patientId = scanner.next();

                    PatientRecord patient = analyser.find(patientId);
                    if (patient != null) {
                        System.out.println(patient.toString());
                    } else {
                        System.out.println("Patient not found.");
                    }
                }

                case 2 -> {
                    // to display records within a specified MAP range

                    double map1 = scanner.nextDouble();
                    double map2 = scanner.nextDouble();
                    // to check whether map1 is less than or not than  map2
                    if (map1 > map2) {
                        System.out.println("Invalid data: Map1 should be less than Map 2");
                        break;
                    }

                    // creating arraylist to store record's within specified range
                    ArrayList<PatientRecord> dataRange = analyser.find(map1, map2);
                    if (dataRange.isEmpty()) {
                        System.out.println("No records found within this range.");
                    } else {
                        for (PatientRecord patients : dataRange) {
                            System.out.println(patients.toString());
                        }

                    }
                }

                case 3 -> {

                    // display the statistics
                    double minMAP = analyser.lowestMAP();
                    double maxMAP = analyser.highestMAP();
                    double medianMAP = analyser.medianMAP();
                    double averageMAP = analyser.averageMAP();

                    System.out.println("Statistics:");
                    System.out.println("Minimum MAP: " + minMAP);
                    System.out.println("Maximum MAP: " + maxMAP);
                    System.out.println("Median MAP: " + medianMAP);
                    System.out.println("Average MAP: " + averageMAP);
                    break;
                }
                case 4 -> {
                    //  display all patient records
                    PatientRecord[] allRecords = analyser.getAllRecords();

                    if (allRecords.length == 0) {
                        System.out.println("No patient records available.");
                    } else {

                        for (PatientRecord patients : allRecords) {
                            System.out.println(patients.toString());
                        }
                    }
                }
                case 9 -> {
                    System.out.println("Exiting the application.");
                    System.exit(0);
                }
                default -> {
                    System.out.println("Invalid command.");
                    commandLoop();
                }

            }
        }
    }
}
