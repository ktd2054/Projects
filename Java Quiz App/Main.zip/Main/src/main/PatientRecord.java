/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author Kshit Student ID: 12215318 
 * The PatientRecord class represents a
 * single patient record with attributes such as ID, blood pressure values, Mean
 * Arterial Pressure (MAP), and a category. It provides a toString method for a
 * minimalist representation of a patient record.
 */
public class PatientRecord {

    private String id;
    private int sbp;
    private int dbp;
    private double map;
    private String category;

    // constructor to initialize instance variables
    /**
     * Constructs a PatientRecord object with the specified attributes.
     *
     * @param id The unique identifier for the patient record.
     * @param sbp The systolic blood pressure value.
     * @param dbp The diastolic blood pressure value.
     * @param map The Mean Arterial Pressure (MAP) value calculated from sbp and
     * dbp.
     * @param category The blood pressure category (e.g., "Low," "Normal," or
     * "High").
     */
    public PatientRecord(String id, int sbp, int dbp, double map, String category) {
        this.id = id;
        this.sbp = sbp;
        this.dbp = dbp;
        this.map = map;
        this.category = category;
    }

    @Override
    public String toString() {
        //  toString method to return a minimalist representation
        return "<" + id + " " + sbp + " " + dbp + " " + map + " " + category + ">";

    }
    // getters and setters for each instance variable

    /**
     * Retrieves the Mean Arterial Pressure (MAP) value of the patient record.
     *
     * @return The MAP value.
     */
    public double getMap() {
        return this.map;

    }

    public String getId() {
        return id;
    }

}
